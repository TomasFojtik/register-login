<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login • Regiter | Tomáš Fojtik</title>

    <link rel="stylesheet" href="./assets/css/index.css">
</head>

<body>

    <div class="container">

        <h1>Tomáš Fojtík</h1>
        <h5>php login a register</h5>

        <div class="nav">
            <button class="btn fr"><a href="./login.php">Login</a></button>
            <button class="btn sc"><a href="./register.php">Register</a></button>
        </div>
    </div>

</body>

</html>