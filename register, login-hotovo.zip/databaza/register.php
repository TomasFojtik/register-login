<?php 
require_once "./app/controllers/connection.php";
?>

<!DOCTYPE html>
<html lang="sk">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Tomáš Fojtík</title>

    <link rel="stylesheet" href="./assets/css/register.css">
</head>

<body>

    <div class="container">
        <h2>Registrácia</h2>
        <p>Vypln si údaje správne</p>
        <form action="./app/controllers/register.php" method="post">
            <div class="ccs">
                <label>Meno</label><br>
                <input type="text" name="username" placeholder="Tomas">
            </div>
            <div class="ccs">
                <label>Priezvisko</label><br>
                <input type="text" name="surname" placeholder="Fojtik">
            </div>
            <div class="ccs">
                <label>Email</label><br>
                <input type="email" name="email" placeholder="fojtik@tomas.sk">
            </div>
            <div class="ccs">
                <label>Heslo</label><br>
                <input type="password" name="password" placeholder="******">
            </div>
            <div class="ccs">
                <label>Znova heslo</label><br>
                <input type="password" name="confirm_password" placeholder="******">
             </div>
            <div class="css">
                <button type="submit" class="btn" value="Submit">Odoslať</button>
            </div>
            <div class="">
                <p>Máš už účet? <a class="reg" href="./login.php">Prihlásiť sa!</a>.</p>
            </div>
        </form>
    </div>

</body>

</html>