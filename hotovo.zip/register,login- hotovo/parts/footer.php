<footer>
:)
</footer>