<!DOCTYPE html>
<html>
<head>
<title>login</title>
    
</head>
    <body>
        <?php
            if($_POST["uname"] == "peter" && $_POST["psw"] == "mrkvicka")
            {
                echo " prihlaseny";
            }
            else {
                echo "chyba";
            }
    
        ?>
    </body>
</html>        