<!DOCTYPE html>
<html>
<head>
<title>login</title>
   
</head>
<body>
    <form action="a.php" method="post">

        <div class="container">
          <label for="uname"><b>Prihlasovacie meno </b></label>
          <input type="text" placeholder="Zadaj prihlasovacie meno " name="uname" required>

          <label for="psw"><b>Heslo</b></label>
          <input type="password" placeholder="Zadaj heslo" name="psw" required>

          <button type="submit">Login</button>
          
        </div>
        
      </form>
</body>
</html>