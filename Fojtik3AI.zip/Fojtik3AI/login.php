<?php 

    include_once("./app/controllers/connection.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Tomáš Fojtík</title>

    <link rel="stylesheet" href="./assets/css/login.css">
</head>

<body>
<?php include('./parts/header.php')?>
    <div class="container">
        <h1>Login</h1>
        <h4>Prosím o vyplnenie údajov.</h4>


        <div class="form">
            <form action="./app/controllers/login.php" method="post" name="login">
                <div class="ccs">
                    <label>Meno</label>
                    <input type="name" name="username" placeholder="username">
                </div>

                <div class="ccs">
                    <label>Heslo</label>
                    <input type="password" name="password" placeholder="******">
                </div>

                <button type="submit" class="" name="submit" value="Login">Prihlásiť</button>

                <h4>Ešte nie si registrovaný/á? <a class="reg" href="./register.php">registrovať sa!</a></h4>
            </form>
        </div>
    </div>

</body>

</html>