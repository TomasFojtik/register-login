<?php include('./parts/header.php')?>

<?php include('./app/controllers/getAllusers.php'); ?>
<main class="container">
    <ul class="list-group">
        <li class="list-group-item">
            <span class="text=danger"> <strong> ID. USERNAME </strong></span>
        </li>
        <?php foreach ($users as $user) : ?>
            <li class="list-group-item">
                <a href="a" class="text-danger"> <?php echo $user["id"]. ". " . $user["username"] ?></a>
            </li>
        <?php endforeach; ?>
    </ul>    
</main>

<?php include('./parts/footer.php')?>