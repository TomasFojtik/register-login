
<?php include('./app/controllers/connection.php');?>   
<main class="container">

        <ul CLASS="list-group">
            <?php foreach ($users as $user) : ?>
              <li class="lidt-group.item">
                </span class="text-danger"> <?php echo $user["id"] . " ". $users["username"] ?></span>
              </li>
            <?php print_r($user) ?>
            <?php endforeach; ?>
        </ul>

</main>
    





