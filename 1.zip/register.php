<!DOCTYPE html>
<html>
  <title>Register</title>
<body>
<form action="register_script.php" method="post">
  <div class="container">
    <h1>Register</h1>
    <p>Vyplňte tento formulár a vytvorte si účet</p>
    <hr>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Zadaj email" name="email" id="email" required>

    <label for="psw"><b>Heslo</b></label>
    <input type="password" placeholder="Zadaj heslo" name="psw" id="psw" required>

    <label for="psw-repeat"><b>Zopakuj heslo</b></label>
    <input type="password" placeholder="Zopakuj heslo" name="psw-repeat" id="psw-repeat" required>
    <hr>

    
    <button type="submit" class="registerbtn">Register</button>
  </div>


</form>
</body>
</html>