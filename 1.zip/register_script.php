<!DOCTYPE html>
<html>
<head>
<title>login</title>
    
</head>
    <body>
        <?php
            if($_POST["psw"] != $_POST["psw-repeat"] )
            {
              echo"hesla nie su rovnake";  
              
            }
                
         
            
            
    
        ?>
    </body>
</html> 